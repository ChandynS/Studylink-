<?php


// INPUT SANITISATION FUNCTION
// Protects system against XSS and injection attacks by cleaning user input before database use.
function sanitizeInput($sData)
{
    $sData = trim($sData); // remove spaces

    $sData = stripslashes($sData); // remove slashes

    $sData = htmlspecialchars($sData, ENT_QUOTES, 'UTF-8'); // escape HTML

    return $sData;
}

?>