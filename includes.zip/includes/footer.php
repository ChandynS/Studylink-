<!--  FOOTER SECTION  -->
</div>

<footer>
    <p><strong>StudyLink</strong></p>
    <p>Connecting Students with Qualified Tutors.</p>
    <p>© 2026 StudyLink</p>
</footer>

</body>
</html>