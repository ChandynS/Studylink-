<?php

// base url (used for navigation links)
define("BASE_URL", "/");

// DB connection settings
$sHost = "sql302.infinityfree.com";
$sUsername = "if0_42295010";
$sPassword = "Ot5cvbPI14Bf";
$sDatabase = "if0_42295010_study_link_database1";


// create DB connection
$objConnection = mysqli_connect(
    $sHost,
    $sUsername,
    $sPassword,
    $sDatabase
);

// Set character encoding
mysqli_set_charset($objConnection, "utf8mb4");


// check connection error
if (!$objConnection)
{
    die("Connection Failed: " . mysqli_connect_error());
}

?>