<?php

// get current user ID
$userID = $_SESSION["user_id"] ?? null;

// counts unread messages 
$totalUnread = 0;

if($userID)
{
    $sSQL = " SELECT COUNT(*) AS total FROM messages WHERE receiver_id = $userID AND is_read = 0 ";
    $result = mysqli_query($objConnection, $sSQL);
    $totalUnread = mysqli_fetch_assoc($result)["total"];
}

?>

<!-- NAVIGATION BAR -->
<nav>
<a href="<?php echo BASE_URL; ?>index.php">Home</a>


<?php if(isset($_SESSION["user_id"])) { ?>

    |
    <a href="<?php echo BASE_URL; ?>inbox.php">
        Messages

        <!-- Unread message badge -->
        <?php if($totalUnread > 0) { ?>
            <span style="background:red;color:white;padding:2px 6px;border-radius:50%;">
                <?php echo $totalUnread; ?>
            </span>
        <?php } ?>
    </a>

    |
    <a href="<?php echo BASE_URL; ?>start_chat.php">New Chat</a>

    <!--navigation bar section for students -->
    <?php if($_SESSION["role"] == "student") { ?>
        |
        <a href="<?php echo BASE_URL; ?>find_tutors.php">Find Tutors</a>
        |
        <a href="<?php echo BASE_URL; ?>become_tutor.php">Become Tutor</a>
        |
        <a href="<?php echo BASE_URL; ?>my_requests.php">My Requests</a>

    <?php } ?>

    <!--navigation bar section for tutors -->
    <?php if($_SESSION["role"] == "tutor") { ?>

        |
        <a href="<?php echo BASE_URL; ?>tutor_requests.php">Tutor Requests</a>
        |
        <a href="<?php echo BASE_URL; ?>tutor/profile.php">My Tutor Profile</a>

    <?php } ?>

    <!--navgiation bar section for admin -->
    <?php if($_SESSION["role"] == "admin") { ?>

        |
        <a href="<?php echo BASE_URL; ?>admin/dashboard.php">Admin Dashboard</a>

    <?php } ?>


    <!-- navigation bar section for once users logged in -->
    |
    Welcome, <strong><?php echo $_SESSION["username"]; ?></strong>
    |
    <a href="<?php echo BASE_URL; ?>logout.php">Logout</a>


    <!--navigation bar section for unauthenticated users -->
<?php } else { ?>
    |
    <a href="<?php echo BASE_URL; ?>register.php">Register</a>
    |
    <a href="<?php echo BASE_URL; ?>login.php">Login</a>

<?php } ?>


|
<a href="<?php echo BASE_URL; ?>about.php">About</a>


</nav>

<hr>