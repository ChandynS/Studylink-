<?php

// Checsk if user is logged in
function requireLogin()
{
    if (!isset($_SESSION["user_id"]))
    {
        // Redirects unauthorised users to login page
        header("Location: login.php");
        exit();
    }
}

// Admin-only access control
function requireAdmin()
{
    requireLogin();

    if ($_SESSION["role"] != "admin")
    {
        header("Location: ../index.php");
        exit();
    }
}

// Tutor-only access control
function requireTutor()
{
    requireLogin();

    if ($_SESSION["role"] != "tutor")
    {
        header("Location: ../index.php");
        exit();
    }
}

// Student-only access control
function requireStudent()
{
    requireLogin();

    if ($_SESSION["role"] != "student")
    {
        header("Location: ../index.php");
        exit();
    }
}

?>