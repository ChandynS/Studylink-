<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>StudyLink</title>

<!-- MAIN STYLESHEET -->
<link rel="stylesheet" href="<?php echo BASE_URL; ?>css/style.css">

</head>

<body>

<!-- MAIN PAGE WRAPPER -->
<div class="container">