<?php

// start session if not already started
if(session_status() == PHP_SESSION_NONE)
{
    session_start();
}

// loads core system files 
require_once("config.php");   // database connection
require_once("functions.php"); // helper functions
require_once("auth.php");      // RBAC system

?>