<?php

// LOADS CORE SYSTEM FILES
require_once("../includes/init.php");

// Student-only access
requireStudent();

// Double-check session
if (!isset($_SESSION["user_id"]))
{
    header("Location: ../login.php");
    exit();
}

// Load layout
include("../includes/header.php");
include("../includes/navbar.php");

?>

<!-- STUDENT BOOKINGS  -->

<div class="container">

    <h2>My Bookings</h2>

    <p>
        This page will display all tutoring sessions booked by the student.
        (Future feature: booking management system)
    </p>

</div>

<?php include("../includes/footer.php"); ?>