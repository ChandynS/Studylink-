<?php

// INITIALISE SYSTEM
require_once("../includes/init.php");


// Student-only access
requireStudent();

if (!isset($_SESSION["user_id"]))
{
    header("Location: ../login.php");
    exit();
}

// Load layout
include("../includes/header.php");
include("../includes/navbar.php");

?>

<!--  STUDENT PROFILE  -->
<div class="container">

    <h2>Student Profile</h2>

    <p>
        <strong>Username:</strong>
        <?php echo $_SESSION["username"]; ?>
    </p>

    <p>
        <strong>Email:</strong>
        <?php echo $_SESSION["email"]; ?>
    </p>

</div>

<?php include("../includes/footer.php"); ?>