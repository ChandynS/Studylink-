<?php

// INITIALISE SYSTEM
require_once("../includes/init.php");

// Student-only access
requireStudent();

// Double session check 
if (!isset($_SESSION["user_id"]))
{
    header("Location: ../login.php");
    exit();
}

// Load UI
include("../includes/header.php");
include("../includes/navbar.php");

?>

<!--  STUDENT DASHBOARD  -->
<div class="container">

    <h2>Student Dashboard</h2>

    <p>
        Welcome, <strong><?php echo $_SESSION["username"]; ?></strong>!
    </p>

    <p>
        This dashboard allows students to find tutors, send requests, and manage bookings.
    </p>

</div>

<?php include("../includes/footer.php"); ?>