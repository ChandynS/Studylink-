<?php

// Load system configuration and database
require_once("../includes/init.php");

// ensures only admin users  allowed
requireAdmin();

// Load layout
include("../includes/header.php");
include("../includes/navbar.php");

?>

<!-- ADMIN BOOKINGS PAGE-->
<div class="container">

    <h2>Manage Tutoring Requests</h2>

    <p>
        This section allows administrators to view all tutoring requests made on the platform.
        (Future enhancement: approve, reject, or cancel requests)
    </p>

    <!-- BOOKINGS TABLE -->
    <table border="1">

        <tr>
            <th>Student</th>
            <th>Tutor</th>
            <th>Status</th>
        </tr>

        <!-- SAMPLE DATA (placeholder for database integration) -->
        <tr>
            <td>student1</td>
            <td>teststudent</td>
            <td>Accepted</td>
        </tr>

    </table>

</div>

<?php include("../includes/footer.php"); ?>