<?php

// Initialise system and database connection
require_once("../includes/init.php");

// ensures only admin users  allowed
requireAdmin();

// Load layout
include("../includes/header.php");
include("../includes/navbar.php");
?>

<!-- SUBJECT MANAGEMENT -->
<div class="container">
    <h2>Manage Subjects(WIP)</h2>

    <p>
        This section displays all available tutoring subjects on the platform.
        (Future enhancement: Add/Edit/Delete subjects)
    </p>

    <!-- SUBJECT TABLE -->
    <table border="1">

        <tr>
            <th>Subject ID</th>
            <th>Subject Name</th>
        </tr>

        <!-- SAMPLE DATA -->
        <tr>
            <td>1</td>
            <td>Mathematics</td>
        </tr>

        <tr>
            <td>2</td>
            <td>Computer Science</td>
        </tr>

        <tr>
            <td>3</td>
            <td>Accounting</td>
        </tr>

        <tr>
            <td>4</td>
            <td>Physics</td>
        </tr>

    </table>

</div>

<?php include("../includes/footer.php"); ?>