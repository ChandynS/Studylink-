<?php

require_once("../includes/init.php");

// ensures only admin users  allowed
requireAdmin();



//Handles Approve or Reject actions
if(isset($_GET["action"]) && isset($_GET["id"]))
{
    $iTutorID = (int)$_GET["id"];

    //approve tutor
    if($_GET["action"] == "approve")
    {
        // Updates tutor profile status
        $sSQL = "
        UPDATE tutor_profiles
        SET approval_status='Approved'
        WHERE tutor_id='$iTutorID'
        ";

        mysqli_query($objConnection, $sSQL);

        //  updates user role
        $sSQL = "
        UPDATE users
        SET role='tutor'
        WHERE user_id=(
            SELECT user_id
            FROM tutor_profiles
            WHERE tutor_id='$iTutorID'
        )
        ";

        mysqli_query($objConnection, $sSQL);
    }

    //reject tutor
    elseif($_GET["action"] == "reject")
    {
        // Updates tutor profile status
        $sSQL = "UPDATE tutor_profiles SET approval_status='Rejected' WHERE tutor_id='$iTutorID'";

        mysqli_query($objConnection, $sSQL);

        // reverts user role to student
        $sSQL = "UPDATE users SET role='student' WHERE user_id=(SELECT user_id FROM tutor_profiles WHERE tutor_id='$iTutorID')";

        mysqli_query($objConnection, $sSQL);
    }

    header("Location: tutors.php");
    exit();
}

//Load tutor applications
$sSQL = "SELECT * FROM tutor_profiles INNER JOIN users ON tutor_profiles.user_id = users.user_id ORDER BY approval_status, username";

$objResult = mysqli_query($objConnection, $sSQL);
mysqli_query( $objConnection, $sSQL);

include("../includes/header.php");
include("../includes/navbar.php");

?>

<div class="container">

<h2>Manage Tutors</h2>

<p>Approve, reject or remove tutor status from registered users.</p>

<table>
<tr>
<th>Username</th>
<th>Qualification</th>
<th>Experience</th>
<th>Hourly Rate</th>
<th>Status</th>
<th>Action</th>
</tr>

<?php while($objTutor = mysqli_fetch_assoc($objResult)){ ?>

<tr>
    
<td>
<?php
echo $objTutor["username"];
?>
</td>

<td>
<?php
echo $objTutor["qualification"];
?>
</td>

<td>
<?php
echo $objTutor["experience"];
?>
</td>

<td>
R<?php
echo $objTutor["hourly_rate"];
?>
</td>

<td>
<?php
echo
$objTutor["approval_status"];
?>
</td>

<td>
<?php
if($objTutor["approval_status"]=="Pending")
{
?>

<a href="tutors.php?action=approve&id=<?php echo $objTutor["tutor_id"]; ?>" Approve </a>

|

<a href="tutors.php?action=reject&id=<?php echo $objTutor["tutor_id"]; ?>"> Reject </a>

<?php
}
elseif( $objTutor["approval_status"]=="Approved")
{
?>

<a href="tutors.php?action=reject&id=<?php echo $objTutor["tutor_id"]; ?>"> Remove Tutor </a>

<?php
}
else
{
echo "Rejected";
}
?>
</td>

</tr>
<?php

}

?>

</table>

</div>

<?php

include("../includes/footer.php");

?>