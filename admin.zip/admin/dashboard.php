<?php


// Load core system configuration
require_once("../includes/init.php");

//  ensures only admin users  allowed
requireAdmin();

// Load UI components
include("../includes/header.php");
include("../includes/navbar.php");
?>

<!-- ADMIN DASHBOARD  -->

<div class="container">
    <h2>StudyLink Administration Dashboard</h2>

    <p>
        Welcome to the StudyLink admin panel. This area is used to manage all platform data including users,
        tutors, bookings, and subjects.
    </p>

    <!-- NAVIGATION MODULES  -->
    <div class="card">

        <h3>Management Modules</h3>

        <ul>
            <li><a href="users.php">Manage Users</a></li>
            <li><a href="tutors.php">Manage Tutors</a></li>
            <li><a href="bookings.php">Manage Tutoring Requests</a></li>
            <li><a href="subjects.php">Manage Subjects</a></li>
        </ul>

    </div>

    <!-- SYSTEM INFO  -->
    <div class="card">

        <h3>System Overview</h3>

        <p>
            This dashboard provides administrative control over the entire StudyLink platform,
            ensuring proper user management, tutor approval, and system organisation.
        </p>

    </div>

</div>

<?php include("../includes/footer.php"); ?>