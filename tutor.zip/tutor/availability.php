<?php


// LOAD SYSTEM CORE
require_once("../includes/init.php");

/ Tutor-only access
requireTutor();

// Extra check 
if (!isset($_SESSION["user_id"]))
{
    header("Location: ../login.php");
    exit();
}

// Load layout
include("../includes/header.php");
include("../includes/navbar.php");

?>

<!-- TUTOR PROFILE  -->
<div class="container">

    <h2>Tutor Profile</h2>

    <p>
        <strong>Username:</strong>
        <?php echo $_SESSION["username"]; ?>
    </p>

    <p>
        <strong>Email:</strong>
        <?php echo $_SESSION["email"]; ?>
    </p>

</div>

<?php include("../includes/footer.php"); ?>