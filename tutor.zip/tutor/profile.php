<?php

// LOAD SYSTEM CORE
require_once("../includes/init.php");

// Tutor-only access
requireTutor();

if (!isset($_SESSION["user_id"]))
{
    header("Location: ../login.php");
    exit();
}

// Load UI
include("../includes/header.php");
include("../includes/navbar.php");
?>

<!--  TUTOR AVAILABILITY  -->
<div class="container">

    <h2>Tutor Availability(WIP)</h2>

    <p>
        This page will allow tutors to set their available tutoring times.
        (Future feature: calendar-based scheduling system)
    </p>

</div>

<?php include("../includes/footer.php"); ?>