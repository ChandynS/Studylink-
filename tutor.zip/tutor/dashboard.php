<?php

// LOAD SYSTEM CORE
require_once("../includes/init.php");

// Tutor-only access
requireTutor();

if (!isset($_SESSION["user_id"]))
{
    header("Location: ../login.php");
    exit();
}

// Load layout
include("../includes/header.php");
include("../includes/navbar.php");

?>

<!--  TUTOR DASHBOARD  -->

<div class="container">

    <h2>Tutor Dashboard</h2>

    <p>
        Welcome, <strong><?php echo $_SESSION["username"]; ?></strong>!
    </p>

    <p>
        This dashboard allows tutors to manage availability, bookings, and student requests.
    </p>

</div>

<?php include("../includes/footer.php"); ?>