<?php


// LOAD SYSTEM CORE
require_once("../includes/init.php");

// Tutor-only access
requireTutor();

// Load UI
include("../includes/header.php");
include("../includes/navbar.php");

?>

<!--TUTOR BOOKINGS -->

<div class="container">

    <h2>Tutor Bookings</h2>

    <p>
        This page will allow tutors to manage incoming tutoring requests from students.
        (Future feature: accept/reject sessions)
    </p>

</div>

<?php include("../includes/footer.php"); ?>